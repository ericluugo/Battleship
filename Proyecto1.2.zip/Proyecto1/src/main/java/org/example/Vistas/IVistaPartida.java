package org.example.Vistas;

import org.example.Dato.Partida;

import java.util.List;
import java.util.Scanner;

public interface IVistaPartida {
	
	public List<Integer> pedirCasilla();

	public boolean pedirDecision();

	public int pedirFila();
}
