package org.example.Vistas;

import org.example.Dato.JugadorHumano;
import org.example.Logica.IControladorJugadores;
import servidor.Autenticacion;

import java.util.Scanner;

public class VistaJugadores implements IVistaJugadores{
    private Scanner teclado;
    private JugadorHumano jugadorLogueado;

    public VistaJugadores(Scanner teclado) {
        this.teclado = teclado;
        this.jugadorLogueado =null;
    }

    public boolean solicitudDatosAlta(IControladorJugadores iControladorJugadores){
        boolean nuevoJugador = true;
        System.out.println("Introduzca su nombre: ");
       String nombre = teclado.next();

        //Nombre unico??


       System.out.println("Introduzca su email ");
       String email = teclado.next();

       if (iControladorJugadores.comprobarEmail(email)){
           System.out.println("Ya esta registrado con este email, inicie Sesion");
           nuevoJugador = false;

           //Comprobar que se usuario de la UPM
       } else if(!Autenticacion.existeCuentaUPMStatic(email)){
           System.out.println("Este email no pertenece a la UPM, no se puede registrar");
           nuevoJugador = false;
       } else{
           //Si esta todo correcto
            System.out.println("Introduzca su contraseña: ");
            String contrasenia = teclado.next();
            JugadorHumano jugador = iControladorJugadores.darAlta(email, nombre, contrasenia);
            System.out.println("Ha iniciado sesion correctamente. ");
            this.jugadorLogueado = jugador;
       }
       return nuevoJugador;
    }

    public JugadorHumano getJugadorLogueado() {
        return jugadorLogueado;
    }
    public boolean iniciarSesion(IControladorJugadores iControladorJugadores){
        boolean sesionIniciada= false;
        System.out.println("Introduce su email: ");
        String email = teclado.next();
        //Comprobar si hay un jugador que ya exista que tenga este email
        if (!iControladorJugadores.comprobarEmail(email)){
            System.out.println("No hay un jugador registrado con este email, debe darse de alta primero");
        }else {
            //Comprobar contraseña
            System.out.println("Introduce la contraseña: ");
            String contrasenia = teclado.next();
            if (!iControladorJugadores.comprobarContrasenia(email, contrasenia)){
                System.out.println("Contraseña incorrecta. ");
            } else {
                this.jugadorLogueado =iControladorJugadores.iniciarSesion(email, contrasenia);
                if (this.jugadorLogueado==null) System.out.println("Ha ocurrido un error al iniciar sesion. ");
                else {
                    sesionIniciada=true;
                    System.out.println("Ha iniciado sesion correctamente. ");
                }
            }
        }
        return sesionIniciada;
    }

    public boolean darBaja(IControladorJugadores iControladorJugadores){
        boolean darBaja= false;
        if (jugadorLogueado != null) {
            darBaja = iControladorJugadores.darBaja(jugadorLogueado);
            if (darBaja) {
                this.jugadorLogueado = null;
                System.out.println("Se ha dado de baja correctamente.");
            } else {
                System.out.println("Error al dar de baja.");
            }
        } else {
            System.out.println("No hay ningún jugador logueado.");
        }
        return darBaja;
        }
    }

