package org.example.Vistas;

import org.example.Dato.JugadorHumano;

public interface IVistaJugadores {
    JugadorHumano getJugadorLogueado();
}
