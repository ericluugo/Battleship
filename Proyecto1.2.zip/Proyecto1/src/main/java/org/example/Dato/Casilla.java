package org.example.Dato;

public class Casilla {
	
	private int fila;
	private int columna;
	private boolean estadoImpactado;
	private boolean estadoVisibilidad;
	private boolean ocupada;
	public Casilla(int fila, int columna) {
		super();
		this.fila = fila;
		this.columna = columna;
		this.estadoImpactado = false;
		this.estadoVisibilidad = false;
		this.ocupada = false;
	}

	public int getColumna() {
		return columna;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	public int getFila() {
		return fila;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

	public boolean isEstadoImpactado() {
		return estadoImpactado;
	}

	public void setEstadoImpactado(boolean estadoImpactado) {
		this.estadoImpactado = estadoImpactado;
	}

	public boolean isEstadoVisibilidad() {
		return estadoVisibilidad;
	}

	public void setEstadoVisibilidad(boolean estadoVisibilidad) {
		this.estadoVisibilidad = estadoVisibilidad;
	}

	public boolean isOcupada() {
		return ocupada;
	}

	public void setOcupada(boolean ocupada) {
		this.ocupada = ocupada;
	}
}
