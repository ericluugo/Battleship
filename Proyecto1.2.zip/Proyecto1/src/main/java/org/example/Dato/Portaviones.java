package org.example.Dato;

import org.example.Vistas.IVistaPartida;

import java.util.List;

public class Portaviones extends Barco {

	
	public Portaviones(String nombre, int numCasillas, Tablero suTablero, List<Casilla> casillas) {
		super(nombre, numCasillas, suTablero, casillas);
	}



	@Override
	public void habilidad(Tablero tableroEnemigo, IVistaPartida vistaPartida) {
		List<Integer> coordenadas = vistaPartida.pedirCasilla();
		tableroEnemigo.recibirCoordenadas(coordenadas);
	}

	@Override
	public boolean habilidadDisponible() {
		return true;
	}
}
