package org.example.Dato;



import org.example.Vistas.IVistaPartida;

import java.util.List;

public class Patrullero extends Barco{
	
	private int numRevelacionesDisponibles;
	private final int NUM_REVELACIONES_DISPONIBLES = 1;

	public Patrullero(String nombre, int numCasillas, Tablero suTablero, List<Casilla> casillas) {
		super(nombre, numCasillas, suTablero,casillas);
		this.numRevelacionesDisponibles = NUM_REVELACIONES_DISPONIBLES;
	}

	@Override
	public void habilidad(Tablero tableroEnemigo, IVistaPartida vistaPartida) {
		int fila = vistaPartida.pedirFila();
		for (int j = 0; j<tableroEnemigo.getNumColumnas();j++){
			getSuTablero().getTablero()[fila][j].setEstadoVisibilidad(true);
		}
	}

	@Override
	public boolean habilidadDisponible() {
		if (numRevelacionesDisponibles > 0){
			numRevelacionesDisponibles--;
			return true;
		}else return false;
	}
}
