package org.example.Dato;

import org.example.Vistas.IVistaPartida;

import java.util.List;

public class Submarino extends Barco {

	private int numReparacionesDisponibles;
	private final int NUM_REPARACIONES_DISPONIBLES = 1;
	
	public Submarino(String nombre, int numCasillas, Tablero suTablero, List<Casilla> casillas) {
		super(nombre, numCasillas, suTablero,casillas);
		this.numReparacionesDisponibles = NUM_REPARACIONES_DISPONIBLES;
	}

	@Override
	public void habilidad(Tablero tableroEnemigo, IVistaPartida vistaPartida) {
		for (Casilla casilla : getCasillas()){
			casilla.setEstadoImpactado(false);
			casilla.setEstadoVisibilidad(false);
		}
	}

	@Override
	public boolean habilidadDisponible() {
		if (numReparacionesDisponibles > 0){
			numReparacionesDisponibles--;
			return true;
		}else return false;
	}
}
