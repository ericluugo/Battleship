package org.example.Logica;

import org.example.Dato.Jugador;
import org.example.Dato.JugadorHumano;
import org.example.Dato.Maquina;
import servidor.ObtencionDeRol;

import java.util.ArrayList;
import java.util.List;

public class ControladorJugadores implements IControladorJugadores{
    private List<Jugador> listaJugadores;
    private List<Maquina> listaMaquinas;

    public ControladorJugadores() {
        this.listaJugadores = new ArrayList<>();
    }



    @Override
    public JugadorHumano darAlta(String email, String nombre, String contrasenia) {
        boolean esAdmin= !ObtencionDeRol.get_UPM_AccountRol(email).equals("ALUMNO");
        JugadorHumano jugador = new JugadorHumano(nombre, email, contrasenia, esAdmin);
        listaJugadores.add(jugador);
        return jugador;
    }


    public boolean darBaja(JugadorHumano jugadorHumano) {
        return listaJugadores.remove(jugadorHumano);
    }

    @Override
    public JugadorHumano iniciarSesion(String email, String contrasenia) {
        Jugador jugador=null;
        int index =0;
        while (index< listaJugadores.size() && jugador==null){
            if (listaJugadores.get(index).comprobarEmailContrasenia(email, contrasenia)){
                jugador = listaJugadores.get(index);
            } else index++;
        }
        return (JugadorHumano) jugador;
    }
    @Override
    public boolean comprobarEmail(String email){
        boolean existe = false;
        int index =0;
        while (index<listaJugadores.size() && !existe){
            if (listaJugadores.get(index).existeEmail(email)) existe=true;
            else index++;
        }
        return existe;
    }
    @Override
    public boolean comprobarContrasenia(String email, String contrasenia){
        boolean correcto =false;
        int index =0;
        while (index<listaJugadores.size() && !correcto){
            if (listaJugadores.get(index).comprobarEmailContrasenia(email, contrasenia)) correcto=true;
            else index++;
        }
        return correcto;
    }

}
