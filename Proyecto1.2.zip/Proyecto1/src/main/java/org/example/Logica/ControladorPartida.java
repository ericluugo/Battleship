package org.example.Logica;

import org.example.Dato.*;
import org.example.Vistas.IVistaPartida;

import java.util.ArrayList;
import java.util.List;

public class ControladorPartida implements IControladorPartida {

    private List<Partida> partidas;

    public ControladorPartida() {
        this.partidas = new ArrayList<>();
    }

    public Partida crearPartida(IJugable jugador1, IJugable jugador2) {
        Partida nuevaPartida = new Partida(jugador1,jugador2);
        return nuevaPartida;
    }

    @Override
    public String generarPuntuaciones(Partida partida) {

    }

    @Override
    public void iniciarPartida(IJugable jugador1, IJugable jugador2) {
        Partida nuevaPartida = crearPartida(jugador1,jugador2);
        nuevaPartida.inicializarPartida();
        jugarPartida(vistaPartida,nuevaPartida);
    }

    public String generarTableros(Partida partida){
        String vistaTableros = "Tablero 1 : " +partida.getJugador1().getId()+ "\n" + partida.getTablero1().mostrarTablero() + "\n" + "Tablero 2 : "+ partida.getJugador2().getId()+ "\n" + partida.getTablero2().mostrarTablero();
        return vistaTableros;
    }

    public void finalizarPartida(Partida partida) {
        int puntuacionJugador1 = 0;
        int puntuacionJugador2 = 0;
        for(Barco barcoFinal : partida.getTablero1().getBarcos()){
            for (Casilla casilla : barcoFinal.getCasillas()) {
                if (casilla.isEstadoImpactado() && casilla.isOcupada()) {
                    if (barcoFinal.isVivo()) puntuacionJugador1 += 2;
                    else puntuacionJugador1 += 5;
                }
            }
            for(int indexI =0; indexI<partida.getTablero2().getTablero().length;indexI++){
                for (int indexJ=0; indexJ<partida.getTablero2().getTablero()[indexI].length;indexJ++){
                    if (partida.getTablero2().getTablero()[indexI][indexJ].isEstadoVisibilidad() && partida.getTablero2().getTablero()[indexI][indexJ].isEstadoImpactado() && !partida.getTablero2().getTablero()[indexI][indexJ].isOcupada()){
                        puntuacionJugador1--;
                    }
                }
            }
        }
        for(Barco barcoFinal : partida.getTablero2().getBarcos()){
            for (Casilla casilla : barcoFinal.getCasillas()) {
                if (casilla.isEstadoImpactado() && casilla.isOcupada()) {
                    if (barcoFinal.isVivo()) puntuacionJugador2 += 2;
                    else puntuacionJugador2 += 5;
                }
            }
            for(int indexI =0; indexI<partida.getTablero1().getTablero().length;indexI++){
                for (int indexJ=0; indexJ<partida.getTablero1().getTablero()[indexI].length;indexJ++){
                    if (partida.getTablero1().getTablero()[indexI][indexJ].isEstadoVisibilidad() && partida.getTablero1().getTablero()[indexI][indexJ].isEstadoImpactado() && !partida.getTablero1().getTablero()[indexI][indexJ].isOcupada()){
                        puntuacionJugador1--;
                    }
                }
            }
        }
        if (partida.getGanador() == partida.getJugador1()){
            puntuacionJugador1 += 20;
            puntuacionJugador2 -= 20;
        } else {
            puntuacionJugador1 -= 20;
            puntuacionJugador2 += 20;
        }
        partida.setPuntosJugador1(puntuacionJugador1);
        partida.setPuntosJugador2(puntuacionJugador2);
    }

    public void jugarPartida(IVistaPartida vistaPartida,Partida partida) {
        Partida partidaEnJuego = partida;
        // Partida iniciada : IJugable vs IJugable
        while (!partidaEnJuego.verificarFinPartida()){
            generarTableros(partidaEnJuego);
            if (partidaEnJuego.isTurno()){
                // turno jugador1
                // imprimir tableros
                Barco atacado = atacar(partidaEnJuego.getTablero2(),partidaEnJuego.getJugador1(),vistaPartida);
                // imprimir por pantalla FALLO o Acierto
                if (atacado != null && atacado.habilidadDisponible()){
                    // imprimir por pantalla Tipo barco pegado
                    if (partidaEnJuego.getJugador1().decisionHabilidad(vistaPartida)){
                        atacado.habilidad(partidaEnJuego.getTablero2(),vistaPartida);
                    }
                }
            }else {
                // turno jugador2
                //imprimir tableros
                    Barco atacado = atacar(partidaEnJuego.getTablero1(),partidaEnJuego.getJugador2(),vistaPartida);
                    // imprimir por pantalla FALLO o Acierto
                    if (atacado != null && atacado.habilidadDisponible()){
                        // imprimir por pantalla Tipo barco pegado
                        if (partidaEnJuego.getJugador2().decisionHabilidad(vistaPartida)){
                            atacado.habilidad(partidaEnJuego.getTablero1(),vistaPartida);
                        }
                    }
            }
            partidaEnJuego.cambiarTurno();
        }
        finalizarPartida(partidaEnJuego);
        //imprimir puntuaciones
        //imprimir ganador
        partidas.add(partidaEnJuego);
    }

    public Barco atacar(Tablero tableroEnemigo,IJugable atacante,IVistaPartida vistaPartida) {
        Barco afectado = tableroEnemigo.recibirCoordenadas(atacante.seleccionarCasilla(vistaPartida));
        return afectado;
    }
}
