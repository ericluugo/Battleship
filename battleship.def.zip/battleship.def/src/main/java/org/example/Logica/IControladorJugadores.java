package org.example.Logica;

import org.example.Dato.Jugadores.JugadorHumano;
import org.example.Dato.Jugadores.Maquina;

public interface IControladorJugadores {
    void darAlta(String email, String nombre, String contrasenia, boolean esAdmin) throws Exception;

    boolean darBaja(JugadorHumano jugadorHumano);

    JugadorHumano iniciarSesion(String email, String contrasenia);

    Maquina crearMaquina() throws Exception;


}
