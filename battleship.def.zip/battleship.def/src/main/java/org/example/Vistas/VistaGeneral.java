package org.example.Vistas;

import org.example.Dato.Jugadores.IJugable;
import org.example.Logica.ControladorJugadores;
import org.example.Logica.ControladorPartida;

import java.util.InputMismatchException;
import java.util.Scanner;

public class VistaGeneral {
    private static final Scanner teclado = new Scanner(System.in);
    private static VistaGeneral instancia;
    private final VistaPartida vistaPartida;
    private final VistaJugadore vistaJugadores;
    private final ControladorPartida controladorPartida;
    private final ControladorJugadores controladorJugadores;
    private boolean finPrograma;


    private VistaGeneral() throws Exception {
        vistaPartida = new VistaPartida();
        vistaJugadores = new VistaJugadore();
        controladorJugadores = ControladorJugadores.getInstancia();
        controladorPartida = ControladorPartida.getInstancia();
        vistaPartida.setControladorPartida(controladorPartida);
        controladorPartida.setVistaAtacable(vistaPartida);
        controladorPartida.setVistaPartida(vistaPartida);
        vistaJugadores.setControladorJugadores(controladorJugadores);
        controladorJugadores.setVistaJugadores(vistaJugadores);
        this.finPrograma = false;
        this.precargaAdmins();
    }

    public static VistaGeneral getInstancia() throws Exception {
        if (instancia == null) {
            instancia = new VistaGeneral();
        }
        return instancia;
    }

    public static int leerNumeroIntervalo(String mensaje, int min, int max) {
        boolean correcto = false;
        int numero = 0;
        while (!correcto) {
            System.out.print(mensaje);
            try {
                numero = teclado.nextInt();
                if (numero >= min && numero <= max) {
                    correcto = true;
                } else {
                    System.out.println("Introduzca una opcion valida...");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, introduzca un número.");
                teclado.next(); // limpia el valor incorrecto del buffer
            }
        }
        return numero;
    }

    public void programa() {
        boolean ejecucionCorrecta = false;
        imprimir("Bienvenido al sistema de juego Battleship");
        do {
            try {
                switchPublico();
                ejecucionCorrecta = true;
            } catch (Exception e) {
                imprimir("Ha ocurrido un error...");
                imprimir(e.getMessage());
            }
        } while (!ejecucionCorrecta);

    }

    private void switchPublico() throws Exception {
        int opcion = 0;
        do {
            imprimir("\t\tGestor de Usuarios\n" +
                    "----------------------------------------\n" +
                    "Inserte 1: Darse de Alta\n" +
                    "Inserte 2: Iniciar Sesión\n" +
                    "Inserte 3: Exit\n");
            opcion = leerNumeroIntervalo("Introduzca el numero de la opcion deseada: ", 1, 3);
            switch (opcion) {
                case 1: //alta
                    vistaJugadores.solicitudAlta();
                    break;
                case 2: // iniciar sesión
                    vistaJugadores.iniciarSesion();
                    if (vistaJugadores.getJugadorLogueado() != null) {
                        switchJugador();
                    }
                    break;
                case 3:
                    imprimir("Fin del sistema de juego Battleship");
                    finPrograma = true;
                    break;
                default:
                    imprimir("Seleccione una opción válida");
                    break;
            }
        } while (opcion != 3 && !finPrograma);
    }

    private void switchJugador() throws Exception {
        if (vistaJugadores.getJugadorLogueado() != null) {
            int opcion = 0;
            do {
                imprimir("\t\tGestor de partidas\n" +
                        "----------------------------------------\n" +
                        "Inserte 1: Iniciar Partida\n" +
                        "Inserte 2: Generar Puntuaciones\n" +
                        "Inserte 3: Darse de baja\n" +
                        "Inserte 4: Cerrar Sesión\n");
                opcion = leerNumeroIntervalo("Introduzca el numero de la opcion deseada: ", 1, 4);
                switch (opcion) {
                    case 1: //iniciarPartida
                        IJugable first_player = vistaJugadores.getJugadorLogueado();
                        IJugable second_player = controladorJugadores.crearMaquina();
                        controladorPartida.iniciarPartida(first_player, second_player);
                        break;
                    case 2: // generarPuntuaciones
                        if (vistaJugadores.getJugadorLogueado().isEsAdmin()) {
                            vistaPartida.mostrarPuntuacionesGlobal();
                        } else {
                            vistaPartida.mostrarPuntuacionesJugador(vistaJugadores.getJugadorLogueado().getId());
                        }
                        break;
                    case 3:// darse de baja
                        if (vistaJugadores.darBaja())
                            switchPublico();
                        break;
                    case 4: // Cerrar sesión
                        imprimir("Cerrando sesión");
                        vistaJugadores.setJugadorLogueado(null);
                        switchPublico();
                        break;
                    default:
                        imprimir("Seleccione una opción válida");
                        break;
                }
            } while (opcion != 4 && !finPrograma);
        }
    }

    private void precargaAdmins() {
        try {
            controladorJugadores.darAlta("admin1@alumnos.upm.es", "Admin1", "Admin1*", true);
            controladorJugadores.darAlta("admin2@alumnos.upm.es", "Admin2", "Admin2*", true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void imprimir(String msg) {
        System.out.println(msg);
    }
}
