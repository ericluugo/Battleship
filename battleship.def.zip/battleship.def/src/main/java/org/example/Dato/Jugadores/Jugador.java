package org.example.Dato.Jugadores;


import java.util.List;

public abstract class Jugador implements IJugable {

	public Jugador(){}

	public abstract List<Integer> seleccionarCasilla();

	public abstract String getId();

	public abstract boolean decisionHabilidad();

	public abstract int seleccionarFila();

	public boolean comprobarEmailContrasenia(String email, String contraseña){
		return false;
	};

}