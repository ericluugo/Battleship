package org.example.Dato.Barcos;

import org.example.Dato.Partida.Casilla;
import org.example.Dato.Partida.Tablero;
import org.example.Logica.ControladorPartida;

import java.util.List;

public class Portaviones extends Barco {


    public Portaviones(String nombre, int numCasillas, List<Casilla> casillas) {
        super(nombre, numCasillas, casillas);
    }


    @Override
    public void habilidad(Tablero tableroEnemigo) {
        List<Integer> coordenadas;
        if (ControladorPartida.getInstancia().getPartidaEnJuego().isTurno()) {
            coordenadas = ControladorPartida.getInstancia().getPartidaEnJuego().getJugador2().seleccionarCasilla();
        } else coordenadas = ControladorPartida.getInstancia().getPartidaEnJuego().getJugador1().seleccionarCasilla();
        if (!tableroEnemigo.isCasillaImpactada(coordenadas)) {
            Barco atacado = tableroEnemigo.recibirCoordenadas(coordenadas);
            ControladorPartida.getInstancia().getVistaPartida().imprimir("Se ha atacado la casilla : [" + coordenadas.get(1) + "][" + coordenadas.get(0) + "] con El Portaviones");
            if (atacado == null) {
                ControladorPartida.getInstancia().getVistaPartida().imprimir("El ataque ha fallado");
            } else {
                atacado.isBarcoMuerto();
                ControladorPartida.getInstancia().getVistaPartida().imprimir("El ataque ha acertado");
            }
        }else ControladorPartida.getInstancia().getVistaPartida().imprimir("Ha atacado a una casilla impactada anteriormente");
    }

    @Override
    public boolean habilidadDisponible() {
        return true;
    }
}
